package easykanban2;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class EasyKanban2 {
    
    public static void main(String[] args) {
        // Simulated user login
        String username = JOptionPane.showInputDialog(null, "Enter your username:");
        String password = JOptionPane.showInputDialog(null, "Enter your password:");
        
        if (!login(username, password)) {
            JOptionPane.showMessageDialog(null, "Invalid login. Exiting...");
            return;
        }
        
        JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");
        
        int option = 0;
        while (option != 3) {
            String optionStr = JOptionPane.showInputDialog(null, 
                "Please choose an option:\n" +
                "1) Add tasks\n" +
                "2) Show report (Coming Soon)\n" +
                "3) Quit");
            option = Integer.parseInt(optionStr);
            switch (option) {
                case 1:
                    addTasks();
                    break;
                case 2:
                    JOptionPane.showMessageDialog(null, "Coming Soon");
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "Exiting...");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option. Please try again.");
                    break;
            }
        }
    }

    public static boolean login(String username, String password) {
        // For simplicity, we assume any non-empty credentials are valid
        return !username.isEmpty() && !password.isEmpty();
    }

    public static void addTasks() {
        String numTasksStr = JOptionPane.showInputDialog(null, "How many tasks do you want to enter?");
        int numTasks = Integer.parseInt(numTasksStr);

        int totalDuration = 0;

        for (int i = 0; i < numTasks; i++) {
            String taskName = JOptionPane.showInputDialog(null, "Enter task name:");

            String taskDescription;
            while (true) {
                taskDescription = JOptionPane.showInputDialog(null, "Enter task description (max 50 characters):");
                if (taskDescription.length() <= 50) {
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters.");
                }
            }

            String devFirstName = JOptionPane.showInputDialog(null, "Enter developer first name:");
            String devLastName = JOptionPane.showInputDialog(null, "Enter developer last name:");

            String taskDurationStr = JOptionPane.showInputDialog(null, "Enter task duration in hours:");
            int taskDuration = Integer.parseInt(taskDurationStr);

            totalDuration += taskDuration;

            String taskId = generateTaskID(taskName, i, devLastName);

            String[] options = {"To Do", "Doing", "Done"};
            int statusOption = JOptionPane.showOptionDialog(null, "Select task status:", "Task Status", 
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

            String taskStatus;
            switch (statusOption) {
                case 0:
                    taskStatus = "To Do";
                    break;
                case 1:
                    taskStatus = "Doing";
                    break;
                case 2:
                    taskStatus = "Done";
                    break;
                default:
                    taskStatus = "Unknown";
                    break;
            }

            String taskDetails = String.format("Task Status: %s\nDeveloper: %s %s\nTask Number: %d\nTask Name: %s\nTask Description: %s\nTask ID: %s\nDuration: %d hours",
                                                taskStatus, devFirstName, devLastName, i, taskName, taskDescription, taskId, taskDuration);

            JOptionPane.showMessageDialog(null, taskDetails, "Task Details", JOptionPane.INFORMATION_MESSAGE);
        }

        JOptionPane.showMessageDialog(null, "Total hours across all tasks: " + totalDuration);
    }

    public static String generateTaskID(String taskName, int taskNumber, String lastName) {
        String taskId = taskName.substring(0, 2).toUpperCase() + ":" + taskNumber + ":" + lastName.substring(lastName.length() - 3).toUpperCase();
        return taskId;
    }
}